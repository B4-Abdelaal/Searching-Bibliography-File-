#include "FileOpsStudent.h"
#include <stdio.h>
#include <string.h>

/**
 * @brief Reads the bibliography entries from a file.
 *
 * @param filename The name of the file to read from.
 * @param entries The array to store the bibliography entries.
 * @param count The number of entries read.
 */
void readFile(char *filename, BibliographyEntry entries[], int *count) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        printf("Could not open file\n");
        return;
    }
    *count = 0;
    char line[1024];
    while (fgets(line, sizeof(line), file)) {
        sscanf(line, "Title {%[^}]}, Author {%[^}]}, Year {%d}, Type {%[^}]}",
               entries[*count].title, entries[*count].author, &entries[*count].year, entries[*count].publicationType);
        (*count)++;
    }
    fclose(file);
}

/**
 * @brief Displays the main menu options.
 */
void displayMenu() {
    printf("\n**********************************************************************************\n");

    printf("1. Search by Author\n");
    printf("2. Search by Title\n");
    printf("3. Search by Year\n");
    printf("4. Search by Year Range\n");
    printf("5. Display Publication Types\n");
    printf("6. Display Authors Alphabetically\n");
    printf("7. Detect Duplicate Titles\n");
    printf("8. Display Harvard Reference\n");
    printf("9. Add Entry\n");
    printf("10. Exit\n");

    printf("\n**********************************************************************************\n");

}

/**
 * @brief Searches bibliography entries by author.
 *
 * @param entries The array of bibliography entries.
 * @param count The number of entries.
 * @param author The author to search for.
 */
void searchByAuthor(BibliographyEntry entries[], int count, char *author) {
    for (int i = 0; i < count; i++) {
        if (strstr(entries[i].author, author) != NULL) {
            printf("\n**********************************************************************************\n");

            printf("Title: %s, Author: %s, Year: %d, Type: %s\n", entries[i].title, entries[i].author, entries[i].year, entries[i].publicationType);
        }
    }
}

/**
 * @brief Searches bibliography entries by title.
 *
 * @param entries The array of bibliography entries.
 * @param count The number of entries.
 * @param title The title to search for.
 */
void searchByTitle(BibliographyEntry entries[], int count, char *title) {
    for (int i = 0; i < count; i++) {
        if (strstr(entries[i].title, title) != NULL) {
            printf("\n**********************************************************************************\n");

            printf("Title: %s, Author: %s, Year: %d, Type: %s\n", entries[i].title, entries[i].author, entries[i].year, entries[i].publicationType);
        }
    }
}

/**
 * @brief Searches bibliography entries by year.
 *
 * @param entries The array of bibliography entries.
 * @param count The number of entries.
 * @param year The year to search for.
 */
void searchByYear(BibliographyEntry entries[], int count, int year) {
    for (int i = 0; i < count; i++) {
        if (entries[i].year == year) {
            printf("\n**********************************************************************************\n");

            printf("Title: %s, Author: %s, Year: %d, Type: %s\n", entries[i].title, entries[i].author, entries[i].year, entries[i].publicationType);
        }
    }
}

/**
 * @brief Searches bibliography entries by a range of years.
 *
 * @param entries The array of bibliography entries.
 * @param count The number of entries.
 * @param startYear The start year of the range.
 * @param endYear The end year of the range.
 */
void searchByYearRange(BibliographyEntry entries[], int count, int startYear, int endYear) {
    for (int i = 0; i < count; i++) {
        if (entries[i].year >= startYear && entries[i].year <= endYear) {

            printf("\n**********************************************************************************\n");

            printf("Title: %s, Author: %s, Year: %d, Type: %s\n", entries[i].title, entries[i].author, entries[i].year, entries[i].publicationType);
        }
    }
}

/**
 * @brief Displays the count of each type of publication.
 *
 * @param entries The array of bibliography entries.
 * @param count The number of entries.
 */
void displayPublicationTypes(BibliographyEntry entries[], int count) {
    int journal = 0, book = 0, conference = 0;
    for (int i = 0; i < count; i++) {
        if (strcmp(entries[i].publicationType, "Journal") == 0) journal++;
        else if (strcmp(entries[i].publicationType, "Book") == 0) book++;
        else if (strcmp(entries[i].publicationType, "Conference") == 0) conference++;
    }
    printf("\n**********************************************************************************\n");

    printf("Journals: %d, Books: %d, Conferences: %d\n", journal, book, conference);
}

/**
 * @brief Displays authors in alphabetical order.
 *
 * @param entries The array of bibliography entries.
 * @param count The number of entries.
 */
void displayAuthorsAlphabetically(BibliographyEntry entries[], int count) {
    char authors[count][256];
    for (int i = 0; i < count; i++) {
        strcpy(authors[i], entries[i].author);
    }
    for (int i = 0; i < count-1; i++) {
        for (int j = i+1; j < count; j++) {
            if (strcmp(authors[i], authors[j]) > 0) {
                char temp[256];
                strcpy(temp, authors[i]);
                strcpy(authors[i], authors[j]);
                strcpy(authors[j], temp);
            }
        }
    }
    for (int i = 0; i < count; i++) {

        printf("%s\n", authors[i]);
    }
}

/**
 * @brief Detects duplicate titles in the bibliography entries.
 *
 * @param entries The array of bibliography entries.
 * @param count The number of entries.
 */
void detectDuplicateTitles(BibliographyEntry entries[], int count) {
    for (int i = 0; i < count-1; i++) {
        for (int j = i+1; j < count; j++) {
            if (strcmp(entries[i].title, entries[j].title) == 0) {
                printf("Duplicate Title Found: %s\n", entries[i].title);
            }
        }
    }
}

/**
 * @brief Displays a bibliography entry in Harvard reference format.
 *
 * @param entry The bibliography entry to display.
 */
void displayHarvardReference(BibliographyEntry entry) {
    printf("%s. (%d). %s. [%s]\n", entry.author, entry.year, entry.title, entry.publicationType);
}

/**
 * @brief Adds a new bibliography entry.
 *
 * @param entries The array of bibliography entries.
 * @param count The number of entries.
 */
void addEntry(BibliographyEntry entries[], int *count) {
    printf("Enter Title: ");
    scanf(" %[^\n]", entries[*count].title);
    printf("Enter Author: ");
    scanf(" %[^\n]", entries[*count].author);
    printf("Enter Year: ");
    scanf("%d", &entries[*count].year);
    printf("Enter Publication Type: ");
    scanf(" %[^\n]", entries[*count].publicationType);
    (*count)++;
}
