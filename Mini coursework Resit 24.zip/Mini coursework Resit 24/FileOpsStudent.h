#ifndef FILE_OPS_STUDENT_H
#define FILE_OPS_STUDENT_H

typedef struct {
    char title[256];
    char author[256];
    int year;
    char publicationType[50];
} BibliographyEntry;

void readFile(char *filename, BibliographyEntry entries[], int *count);
void displayMenu();
void searchByAuthor(BibliographyEntry entries[], int count, char *author);
void searchByTitle(BibliographyEntry entries[], int count, char *title);
void searchByYear(BibliographyEntry entries[], int count, int year);
void searchByYearRange(BibliographyEntry entries[], int count, int startYear, int endYear);
void displayPublicationTypes(BibliographyEntry entries[], int count);
void displayAuthorsAlphabetically(BibliographyEntry entries[], int count);
void detectDuplicateTitles(BibliographyEntry entries[], int count);
void displayHarvardReference(BibliographyEntry entry);
void addEntry(BibliographyEntry entries[], int *count);

#endif // FILE_OPS_STUDENT_H
